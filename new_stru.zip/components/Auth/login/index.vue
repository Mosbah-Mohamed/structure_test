<template>
  <div class="login">
    <div class="container">
      <h1 class="text-xl font-semibold">Responsive Layout</h1>
      <p>This container adapts to different screen sizes.</p>
    </div>
  </div>
</template>

<script setup lang="ts">
// definePageMeta({
//     layout: 'second'
// })
</script>

<style lang="scss" scoped></style>

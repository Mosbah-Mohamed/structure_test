export default defineNuxtLink({
  componentName: "customLink",
  activeClass: "custom-active-link",
  exactActiveClass: "exact-custom-active-link",
});

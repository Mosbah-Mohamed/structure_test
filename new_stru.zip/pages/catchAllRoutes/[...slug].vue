<template>
    <div>

        <h1>catch all route page {{ $route.params.slug }}</h1>

    </div>
</template>

<script setup>
definePageMeta({
    layout: 'second'
})
</script>

<style lang="scss" scoped></style>
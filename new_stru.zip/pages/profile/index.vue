<template>
    <div>

        <h1>profile.vue</h1>

    </div>
</template>

<script setup>
definePageMeta({
    layout: 'second'
})
</script>

<style lang="scss" scoped></style>

// @ts-nocheck
import locale_D_58_D_58_importantCourse_nuxt_3_structure_main_str_locales_en_json from "../locales/en.json";
import locale_D_58_D_58_importantCourse_nuxt_3_structure_main_str_locales_ar_json from "../locales/ar.json";


export const localeCodes =  [
  "en",
  "ar"
]

export const localeLoaders = {
  "en": [{ key: "../locales/en.json", load: () => Promise.resolve(locale_D_58_D_58_importantCourse_nuxt_3_structure_main_str_locales_en_json), cache: true }],
  "ar": [{ key: "../locales/ar.json", load: () => Promise.resolve(locale_D_58_D_58_importantCourse_nuxt_3_structure_main_str_locales_ar_json), cache: true }]
}

export const vueI18nConfigs = [
  
]

export const nuxtI18nOptions = {
  "experimental": {
    "localeDetector": "",
    "switchLocalePathLinkSSR": false,
    "autoImportTranslationFunctions": false
  },
  "bundle": {
    "compositionOnly": true,
    "runtimeOnly": false,
    "fullInstall": true,
    "dropMessageCompiler": false
  },
  "compilation": {
    "jit": true,
    "strictMessage": true,
    "escapeHtml": false
  },
  "customBlocks": {
    "defaultSFCLang": "json",
    "globalSFCScope": false
  },
  "vueI18n": "",
  "locales": [
    {
      "name": "English",
      "code": "en",
      "dir": "ltr",
      "files": [
        "D:/importantCourse/nuxt_3_structure/main_str/locales/en.json"
      ]
    },
    {
      "name": "عربي",
      "code": "ar",
      "dir": "rtl",
      "files": [
        "D:/importantCourse/nuxt_3_structure/main_str/locales/ar.json"
      ]
    }
  ],
  "defaultLocale": "",
  "defaultDirection": "ltr",
  "routesNameSeparator": "___",
  "trailingSlash": false,
  "defaultLocaleRouteNameSuffix": "default",
  "strategy": "prefix_except_default",
  "lazy": false,
  "langDir": null,
  "detectBrowserLanguage": {
    "alwaysRedirect": false,
    "cookieCrossOrigin": false,
    "cookieDomain": null,
    "cookieKey": "i18n_redirected",
    "cookieSecure": false,
    "fallbackLocale": "",
    "redirectOn": "root",
    "useCookie": true
  },
  "differentDomains": false,
  "baseUrl": "",
  "dynamicRouteParams": false,
  "customRoutes": "page",
  "pages": {},
  "skipSettingLocaleOnNavigate": false,
  "types": "composition",
  "debug": false,
  "parallelPlugin": false,
  "multiDomainLocales": false,
  "i18nModules": []
}

export const normalizedLocales = [
  {
    "name": "English",
    "code": "en",
    "dir": "ltr",
    "files": [
      {
        "path": "D:/importantCourse/nuxt_3_structure/main_str/locales/en.json"
      }
    ]
  },
  {
    "name": "عربي",
    "code": "ar",
    "dir": "rtl",
    "files": [
      {
        "path": "D:/importantCourse/nuxt_3_structure/main_str/locales/ar.json"
      }
    ]
  }
]

export const NUXT_I18N_MODULE_ID = "@nuxtjs/i18n"
export const parallelPlugin = false
export const isSSG = false

export const DEFAULT_DYNAMIC_PARAMS_KEY = "nuxtI18n"
export const DEFAULT_COOKIE_KEY = "i18n_redirected"
export const SWITCH_LOCALE_PATH_LINK_IDENTIFIER = "nuxt-i18n-slp"

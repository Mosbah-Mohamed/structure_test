export const useReward = () => useState("reward", () => 10);

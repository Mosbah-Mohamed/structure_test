// named export

export const useCart = () => {
  return "product cart";
};

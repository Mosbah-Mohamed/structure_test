<template>
    <div>

        <h1>hello from group user page id page</h1>

    </div>
</template>

<script setup>
definePageMeta({
    layout: 'second'
})
</script>

<style lang="scss" scoped></style>
<template>
  <div>
    <LazyAuthLogin />
  </div>
</template>

<script setup>
definePageMeta({
  layout: "custom",
});
</script>

<style lang="scss" scoped></style>

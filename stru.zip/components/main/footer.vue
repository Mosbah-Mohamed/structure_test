<template>
    <div>

        <h3>footer component</h3>

    </div>
</template>

<script setup>
// definePageMeta({
//     layout: 'second'
// })
</script>

<style lang="scss" scoped></style>
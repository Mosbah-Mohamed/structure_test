// named export

export const useUser = () => {
  return "mosbah mohamed";
};

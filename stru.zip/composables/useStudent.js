// export default

export default () => {
  return "kayan mosbah";
};

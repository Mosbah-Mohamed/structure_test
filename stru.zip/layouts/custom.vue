<template>
    <div class="container">
        <h1>custom layout header</h1>

        <slot />

        <h1>custom layout footer</h1>
    </div>
</template>


<style lang="scss" scoped></style>
<template>
  <div>
    <slot />
  </div>
</template>

<script lang="ts" setup></script>

<style scoped></style>
